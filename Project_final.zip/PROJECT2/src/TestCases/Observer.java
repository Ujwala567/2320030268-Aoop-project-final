package TestCases;

public interface Observer {
void update(String state);

static void setState(String string) {
	// TODO Auto-generated method stub
	
}

static void addObserver(Observer observerA) {
	// TODO Auto-generated method stub
	
}

static void removeObserver(Observer observerA) {
	// TODO Auto-generated method stub
	
}
}
