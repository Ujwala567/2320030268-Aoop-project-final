package MultipleObserver;

public class Observable {

	public static void main(String[] args) {
		System.out.println("This is observable class");
	}

	public void addObserver(ConcreteObserverB observerB) {
	
	}

	public void addObserver(ConcreteObserverA observerA) {
		
		
	}
	public void getState(String string) {
		
		
	}

	public void setState(String string) {
		
		
	}

	public void removeObserver(ConcreteObserverA observerA) {
			
	}
	

}

