package observer;

public class Observer {

	public static void main(String[] args) {
		System.out.println("This is Observer Class");

	}

	public void update(String state) {
	System.out.println("Upadated state");
		
	}

}
