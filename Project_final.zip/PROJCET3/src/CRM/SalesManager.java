package CRM;

public class SalesManager {

	public void addSale(Sale sale1) {
		
		// TODO Auto-generated method stub
		
	}

}
